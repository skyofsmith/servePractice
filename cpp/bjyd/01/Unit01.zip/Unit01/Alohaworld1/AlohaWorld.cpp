#include <iostream>

#include "DisplayMessage.h"

int main() {
    std::cout << "Welcome!" << std::endl;
    displayMessage();
    
	return 0;
}
