#include <iostream>

#include "DisplayMessage.h"

void displayMessage(){
    std::cout << "Aloha World!" << std::endl;
}
