#include <iostream>
int main() {
    //Display Aloha to the console
    cout << "Aloha world!" << endl;
    return 0;
}
